public class ShoppingCentre {
    public String addProduct(String name, double price, String producer) {
        return "";
    }

    public String delete(String name, String producer) {
        return "";
    }

    public String delete(String producer) {
        return "";
    }

    public String findProductsByName(String name) {
        return "";
    }

    public String findProductsByProducer(String producer) {
        return "";
    }

    public String findProductsByPriceRange(double priceFrom, double priceTo) {
        return "";
    }
}
